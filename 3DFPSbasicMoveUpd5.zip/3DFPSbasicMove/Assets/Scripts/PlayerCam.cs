using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCam : MonoBehaviour
{

    Camera cam;


    public float sensX;
    public float sensY;

    public Transform orientation;

    float xRotation;
    float yRotation;
   
    private void Start()
    {// this little bit here just locks the mouse cursor to the middle of the screen and makes it invisible, not too hard to remember
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        cam = GetComponent<Camera>();
       
    }


    private void Update()
    {


        Ray ray = cam.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, 4f) && hit.transform.gameObject.tag == "DoorButton")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                hit.collider.gameObject.SendMessage("DoorButtonPressed");

            }
        }

        if (Physics.Raycast(ray, out hit, 4f) && hit.transform.gameObject.tag == "LiftButton")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                hit.collider.gameObject.SendMessage("LiftButtonPress");

            }
        }



        // this part is just getting the mouse inputs for the X and Y axis
        float mouseX = Input.GetAxisRaw("Mouse X") * Time.deltaTime * sensX;
        float mouseY = Input.GetAxisRaw("Mouse Y") * Time.deltaTime * sensY;


        //this part is wierd but it just sort of works? its how unity handles its rotations for the mouse in a weird way so idk
        yRotation += mouseX;

        xRotation -= mouseY;
        
        // this thing below stops the mouse cursor from going past 90 degress either way, stops the player from being able to bend over backwards and look at everything upside down.
        xRotation = Mathf.Clamp(xRotation, -90f, 90f); 


        //this is for when the camera actuallly rotates and how it controlls its oreientation. the first time we do it is to rotate the camera on both axis, and the second time is to rotate the player on the Y axis
        transform.rotation = Quaternion.Euler(xRotation, yRotation, 0);
        orientation.rotation = Quaternion.Euler(0, yRotation, 0); 
    }
}
