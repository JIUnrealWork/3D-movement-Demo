using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PhysicsPickup : MonoBehaviour
{


    [SerializeField] private LayerMask pickupMask;
    [SerializeField] private Camera playerCamera;
    [SerializeField] private Transform pickupTarget;
    [Space]
    [SerializeField] private float pickupRange;
    private Rigidbody currentObject;
    public float clickPushForce;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {


        if (Input.GetKeyDown(KeyCode.E)) // this iff statement is just to check if the player has pressed a key to make the rest of it do something
        {
            if(currentObject)
            {
                currentObject.useGravity = true;
                currentObject = null;
                return;
            }



            Ray CameraRay = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f)); // this is the raycast we use.
            
            // inside this if statement we use another if statement to check the object that the player has selected
            if(Physics.Raycast(CameraRay, out RaycastHit HitInfo, pickupRange, pickupMask)) // when the raycast hits a specific object (I.E the object with the pickupmask attached to it) asign the rigidbody of that hit object onto the current object variable. this bit is a little confusing and i dont really know how it works. think about it for later
            {
                currentObject = HitInfo.rigidbody;
                currentObject.useGravity = false;
            }

        }

    }

    private void FixedUpdate() // this is used to changed the velocity of the currentObject so we can move it around, we dont use normal update since it would not be consistent
    {
        if (currentObject) //checks if a current object exists, if one doesent then nothing happens
        {
            Vector3 DirectionToPoint = pickupTarget.position - currentObject.position;
            float DistanceToPoint = DirectionToPoint.magnitude;

            currentObject.velocity = DirectionToPoint * 12f * DistanceToPoint;
        }

    }
}
