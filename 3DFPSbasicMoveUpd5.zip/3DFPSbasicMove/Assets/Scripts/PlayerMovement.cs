using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Movement")]
    private float moveSpeed;
    public float walkSpeed;
    public float sprintSpeed;

    public float groundDrag;

    public float jumpForce;
    public float jumpCooldown;
    public float airMultiplier;
    bool readyToJump ;

    [Header("Crouching")]
    public float crouchSpeed;
    public float crouchYScale;
    private float startYScale;


    [Header("Keybinds")] // self explanitory, get  a script to detect an input with this key and when it does, do a thing.
    public KeyCode jumpKey = KeyCode.Space;
    public KeyCode sprintKey = KeyCode.LeftShift;
    public KeyCode crouchKey = KeyCode.LeftControl;

    [Header("Ground Check")]
    public float playerHeight;
    public LayerMask whatIsGround; // this layer mask is what the raycast detects when it is looking for the ground.
    bool grounded;

    [Header("Slope Handling")] // variables for basic slope movement
    public float maxSlopeAngle;
    private RaycastHit slopeHit;
    private bool exitingSlope; // this bool his here specifically so we can jump off of the slopes if we need too, and on the scripts we put it on we check if it hasnt been set to true, and if it has to make it so the player can leave the slope by jumping

    public Transform orientation;

    float horizontalInput;
    float verticalInput;

    Vector3 moveDirection;

    Rigidbody rb;

    public MovementState state;
    public enum MovementState
    {
        walking,
        sprinting,
        crouching,
        air
    }

    private void Start()
    {
        rb = GetComponent<Rigidbody>(); //this in void start is just so we can get a reference to the rigid body, and to freaze its rotation so that the player dosent topple over.
        rb.freezeRotation = true;

        readyToJump = true;

        startYScale = transform.localScale.y;
    }
    private void Update()
    {
        // we use a raycast to check if the player is touching the ground, we get where its coming from, which direction it is going, its max distance and what its checking for
        grounded = Physics.Raycast(transform.position, Vector3.down, playerHeight * 0.5f + 0.2f, whatIsGround);

        MyInput();
        SpeedControll();
        StateHandler();

        //this part below is just to handle the drag on the player
        if (grounded)
        {
            rb.drag = groundDrag;
        }
        else
        {
            rb.drag = 0;
        }
    }

    private void FixedUpdate()
    {
        MovePlayer();
    }

    private void MyInput() // in this part here we are just defining the inputs for the movement, so for hoorizontal it would be left and right inputs and Vertical would be up and down inputs.
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");
        verticalInput = Input.GetAxisRaw("Vertical");

        
        //check if the jump key is pressed
        if(Input.GetKey(jumpKey) && readyToJump && grounded)
        {
            
            readyToJump = false;

            Jump();

            Invoke(nameof(ResetJump), jumpCooldown);
        }

        //crouching
        if (Input.GetKeyDown(crouchKey))
        {
            transform.localScale = new Vector3(transform.localScale.x, crouchYScale, transform.localScale.z);
            rb.AddForce(Vector3.down *5f, ForceMode.Impulse);
        }

        if (Input.GetKeyUp(crouchKey))
        {
            transform.localScale = new Vector3(transform.localScale.x, startYScale, transform.localScale.z);
        }
    }

    private void StateHandler()
    {
        if (Input.GetKey(crouchKey))
        {
            state = MovementState.crouching;
            moveSpeed = crouchSpeed;
        }

        //Mode for sprinting
        if(grounded && Input.GetKey(sprintKey))
        {
            state = MovementState.sprinting;
            moveSpeed = sprintSpeed;
        }
        else if (grounded)
        {
            state = MovementState.walking;
            moveSpeed = walkSpeed; 
        }
        else
        {
            state = MovementState.air;
        }
    }

    private void MovePlayer()
    {
        //calculates the movement direction so that you will always walk in the direction your looking if you walk forward
        moveDirection = orientation.forward *verticalInput + orientation.right * horizontalInput;

        //On a slope
        if (OnSlope() && !exitingSlope)
        {
            rb.AddForce(GetSlopeMoveDirection() * moveSpeed * 20f, ForceMode.Force);

            if(rb.velocity.y > 0) // this if statement is just here to prvent the player from bouncing when they ar on the slope, it does this just by applying a bit of downward force to the player object.
            {
                rb.AddForce(Vector3.down * 80f, ForceMode.Force);
            }
        }

        if (grounded) // on the ground
        {
        rb.AddForce(moveDirection.normalized * moveSpeed * 10f, ForceMode.Force); //this bit adds the force to the player when they are on the ground
        }

        else if(!grounded) // in the air
        {
            rb.AddForce(moveDirection.normalized * moveSpeed * airMultiplier, ForceMode.Force); // so this bit is for when we are in the air, so we multiply the movespeed with the airMultiplier
        }

        // this turns off gravity when we are on the slope, so that we dont just start slowly sliding back down any slope we start walking up 
        rb.useGravity = !OnSlope();
    }

    private void SpeedControll() // this part here is to make sure that when we move we dont go over the players movespeed when we are just moving
    {
        if (OnSlope() && !exitingSlope) // this part here is just to limit the speed of the playe when they are on a slope, as they go slightly faster due to the slopes elivation.
        {
            if(rb.velocity.magnitude > moveSpeed)
            {
                rb.velocity = rb.velocity.normalized * moveSpeed;
            }
        }
        else // we put the normal speed limiting in this else statement because this is just so we can limit the players speed more effectiveley when they are not on a slope.
        {
            Vector3 flatVel = new Vector3(rb.velocity.x, 0f, rb.velocity.z);

            //limit the velocity if needed
            if (flatVel.magnitude > moveSpeed)
            { //so if you go faster than your movement speed then you calculate what your max velicty would be and then apply said max velocity to the player
                Vector3 limitedVel = flatVel.normalized * moveSpeed;
                rb.velocity = new Vector3(limitedVel.x, rb.velocity.y, limitedVel.z);
            }

        }


    }
    private void Jump()
    {
        exitingSlope = true;

        //before we jump, we need to make sure our Y velocity is set to 0, this makes it so that the jump is consistent every time, which we do below
        rb.velocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);

        rb.AddForce(transform.up * jumpForce, ForceMode.Impulse);
    }
    private void ResetJump()
    {
        readyToJump = true; // this just sets ready to jump back to true

        exitingSlope = false;
    }
    
    private bool OnSlope()
    {
        if(Physics.Raycast(transform.position, Vector3.down, out slopeHit, playerHeight * 0.5f + 0.3f)) // this part is just shooting out a raycast so we can detect if we are or arent on a slope. the little "out slopeHit" sorts/stores the information of the object it hits in the slopeHit Variable
        {
            float angle = Vector3.Angle(Vector3.up, slopeHit.normal); // we use a vector3.Angle to get the angle of a given object, and then below this line we use a bool to return true if the angle is smaller than the max slope angle and it isnt 0
            return angle < maxSlopeAngle && angle != 0f;
        }
        return false; // this is for if the raycast dosent return or detect anything that is a slope
    }

    private Vector3 GetSlopeMoveDirection()
    {
        return Vector3.ProjectOnPlane(moveDirection, slopeHit.normal).normalized; // because its returning a direction, we have to normalize it. this bit projects our normal movement direction to the slopes elivation so the script knows where to move up with the slope
    }
}