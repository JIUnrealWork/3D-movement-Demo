using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LiftButtonPressed : MonoBehaviour
{
    
    public Animator liftDoorAnim;


    // Start is called before the first frame update
    void Start()
    {

    }

    public void LiftButtonPress()
    {
        if (liftDoorAnim.GetCurrentAnimatorStateInfo(0).IsName("LiftResting"))
        {
            liftDoorAnim.SetTrigger("Opening");
        }
        else
        {
            liftDoorAnim.SetTrigger("Closing");
        }
    }
}
