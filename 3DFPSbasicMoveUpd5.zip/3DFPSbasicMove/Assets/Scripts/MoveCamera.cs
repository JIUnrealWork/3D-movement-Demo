using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCamera : MonoBehaviour
{


    // this script here just makes it so that the camera always moves with the player so we dont get a scenario where the player can just run away from the camera
    public Transform cameraPosition;

    private void Update() 
    {
        transform.position = cameraPosition.position;
    }
}
