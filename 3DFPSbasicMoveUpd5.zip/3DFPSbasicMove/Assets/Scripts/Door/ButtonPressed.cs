using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonPressed : MonoBehaviour
{
    public Animator buttonDoorAnim;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void DoorButtonPressed()
    {
        if (buttonDoorAnim.GetCurrentAnimatorStateInfo(0).IsName("ButtonDoorClosed"))
        {
            buttonDoorAnim.SetTrigger("Opening");
        }
        else
        {
            buttonDoorAnim.SetTrigger("Closing");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
