using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorTrigger : MonoBehaviour
{
    public Animator slidingDoorAnim;

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            slidingDoorAnim.SetTrigger("Opening");
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if(other.tag == "Player")
        {
            slidingDoorAnim.SetTrigger("Closing");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
